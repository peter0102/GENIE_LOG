package fr.uha.ensisa.gl.tasks;

public class Task {

    private String description;

    public void setDescription(String description) {
        this.description = description;
    }

    public Object getDescription() {
        return this.description;
    }

}
