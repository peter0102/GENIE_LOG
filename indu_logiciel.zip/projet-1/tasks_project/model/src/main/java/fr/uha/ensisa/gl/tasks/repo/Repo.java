package fr.uha.ensisa.gl.tasks.repo;

public interface Repo {
    public TaskRepo getTaskRepo();
}
