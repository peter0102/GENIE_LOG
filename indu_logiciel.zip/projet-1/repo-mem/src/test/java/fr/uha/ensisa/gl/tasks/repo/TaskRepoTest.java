package test.java.fr.uha.ensisa.gl.tasks.repo;

public class TaskRepoTest {
    
}
